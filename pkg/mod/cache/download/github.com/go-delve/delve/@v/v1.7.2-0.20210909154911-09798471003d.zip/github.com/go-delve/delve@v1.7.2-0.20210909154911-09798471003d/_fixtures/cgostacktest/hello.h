#ifndef __HELLO_H__
#define __HELLO_H__

void helloworld(int);
void helloworld_pt3(int);

#endif
